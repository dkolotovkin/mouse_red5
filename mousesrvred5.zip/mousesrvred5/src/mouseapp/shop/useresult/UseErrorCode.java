package mouseapp.shop.useresult;

public class UseErrorCode {
	public static int HEALING_OK = 0;
	public static int GAMEACTION_OK = 1;
	public static int ERROR = 2;
}
