package mouseapp.shop.buyresult;

import mouseapp.shop.itemprototype.ItemPrototype;

public class BuyResult {
	public ItemPrototype itemprototype;
	public byte error;
}
