package mouseapp.utils.gameaction;

public class GameActionSubType {
	public static byte GOTOLEFT = 0;
	public static byte GOTORIGHT = 1;
	public static byte JUMP = 2;
	
	public static byte FINDSOURCE = 3;
	public static byte FINDEXIT = 4;
}
