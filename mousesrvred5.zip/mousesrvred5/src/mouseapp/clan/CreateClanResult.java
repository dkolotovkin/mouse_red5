package mouseapp.clan;

public class CreateClanResult {
	public int clanid;
	public byte error;	
	public String clantitle;
	public int clandeposite;
	public int clandepositm;
	public int clanrole;
	public int money;
}
