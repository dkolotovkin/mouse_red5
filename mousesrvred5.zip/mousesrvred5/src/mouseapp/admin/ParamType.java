package mouseapp.admin;

public class ParamType {
	public static int MONEY = 0;	
	public static int EXPERIENCE = 1;	
	public static int POPULAR = 2;
	public static int NAME = 3;
}
