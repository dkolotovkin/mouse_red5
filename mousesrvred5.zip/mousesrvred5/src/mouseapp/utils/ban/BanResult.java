package mouseapp.utils.ban;

public class BanResult {
	public static byte OK = 0;
	public static byte NO_MONEY = 1;
	public static byte OTHER = 2;
}
