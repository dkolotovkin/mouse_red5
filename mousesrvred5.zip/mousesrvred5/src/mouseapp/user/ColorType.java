package mouseapp.user;

public class ColorType {
	public static byte GRAY = 0;
	public static byte BLACK1 = 1;
	public static byte BLACK3 = 2;
	public static byte BLACK10 = 3;
	public static byte WHITE1 = 4;
	public static byte WHITE3 = 5;
	public static byte WHITE10 = 6;
	public static byte BLUE1 = 7;
	public static byte BLUE3 = 8;
	public static byte BLUE10 = 9;
	public static byte ORANGE1 = 10;
	public static byte ORANGE3 = 11;
	public static byte ORANGE10 = 12;
	public static byte FIOLET1 = 13;
	public static byte FIOLET3 = 14;
	public static byte FIOLET10 = 15;
}
