package mouseapp.utils.extraction;

public class ExtractionData {
	public int experience = 0;
	public int cexperience = 0;
	public int money = 0;
	
	public int experiencebonus = 0;
	public int cexperiencebonus = 0;
	public int moneybonus = 0;
	
	public int artefactID = 0;
	
	public ExtractionData(int experience, int money){
		this.experience = experience;
		this.money = money;
	}
}
