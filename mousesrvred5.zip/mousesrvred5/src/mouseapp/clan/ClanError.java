package mouseapp.clan;

public class ClanError {
	public static byte OK = 0;
	public static byte CLAN_EXIST = 1;
	public static byte NOT_ENOUGHT_MONEY = 2;
	public static byte OTHER = 3;
	public static byte INOTHERCLAN = 4;
	
	public static byte YOUNOTOWNER = 5;
	public static byte USEROFFLINE = 6;
	public static byte LOWLEVEL = 7;
	public static byte NOROLE = 8;
	public static byte TIMEERROR = 9;
}
