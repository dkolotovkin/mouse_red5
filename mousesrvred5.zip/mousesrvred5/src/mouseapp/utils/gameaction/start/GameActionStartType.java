package mouseapp.utils.gameaction.start;

public class GameActionStartType {
	public static byte SIMPLE = 0;
	public static byte BET = 1;
	public static byte BETS = 2;
}
