package mouseapp.clan;

public class ClanDeposit {
	public int depositm = 0;
	public int deposite = 0;
}
