package mouseapp.shop.checkluckresult;

public class CheckLuckResult {
	public byte error;
	public int usermoney;
	public int addmoney;
	public int result;
}
