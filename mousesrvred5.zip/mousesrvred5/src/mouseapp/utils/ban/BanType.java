package mouseapp.utils.ban;

public class BanType {
	public static byte NO_BAN = 0;
	public static byte MINUT5 = 1;
	public static byte MINUT15 = 2;
	public static byte MINUT30 = 3;
	public static byte HOUR1 = 4;
	public static byte DAY1 = 5;
}
