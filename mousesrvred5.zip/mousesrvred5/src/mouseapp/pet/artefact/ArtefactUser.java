package mouseapp.pet.artefact;

public class ArtefactUser {
	public int id;	
	public int type;
	
	public ArtefactUser(int id, int type){
		this.id = id;
		this.type = type;		
	}
}
