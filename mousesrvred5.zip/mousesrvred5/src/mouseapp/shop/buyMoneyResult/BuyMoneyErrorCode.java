package mouseapp.shop.buyMoneyResult;

public class BuyMoneyErrorCode {
	public static byte OK = 0;
	public static byte ERROR = 1;
}
