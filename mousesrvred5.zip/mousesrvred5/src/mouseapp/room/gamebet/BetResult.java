package mouseapp.room.gamebet;

public class BetResult {
	public static byte OK = 0;
	public static byte NO_ROOM = 1;
	public static byte NO_MONEY = 2;
	public static byte NO_USER = 3;
	public static byte OTHER = 4;
}
