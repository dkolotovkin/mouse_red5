package mouseapp.user;

public class AccessoryType {
	public static byte NOACCESSORY = 0;
	
	public static byte PEN1 = 1;
	public static byte PEN3 = 2;
	public static byte PEN10 = 3;
	
	public static byte BANDAGE1 = 4;
	public static byte BANDAGE3 = 5;
	public static byte BANDAGE10 = 6;
	
	public static byte CRONE1 = 7;
	public static byte CRONE3 = 8;
	public static byte CRONE10 = 9;
	
	public static byte CYLINDER1 = 10;
	public static byte CYLINDER3 = 11;
	public static byte CYLINDER10 = 12;
	
	public static byte COOKHAT1 = 13;
	public static byte COOKHAT3 = 14;
	public static byte COOKHAT10 = 15;
	
	public static byte KOVBOYHAT1 = 16;
	public static byte KOVBOYHAT3 = 17;
	public static byte KOVBOYHAT10 = 18;
	
	public static byte FLASHHAIR1 = 19;
	public static byte FLASHHAIR3 = 20;
	public static byte FLASHHAIR10 = 21;		
	
	public static byte PUMPKIN1 = 22;
	public static byte PUMPKIN3 = 23;
	public static byte PUMPKIN10 = 24;
	
	public static byte NYHAT1 = 25;
	public static byte NYHAT3 = 26;
	public static byte NYHAT10 = 27;
	
	public static byte NY1 = 28;
	public static byte NY3 = 29;
	public static byte NY10 = 30;
	
	public static byte DOCTOR1 = 31;
	public static byte DOCTOR3 = 32;
	public static byte DOCTOR10 = 33;
	
	public static byte HELMET1 = 34;
	public static byte HELMET3 = 35;
	public static byte HELMET10 = 36;
	
	public static byte POLICEHAT1 = 37;
	public static byte POLICEHAT3 = 38;
	public static byte POLICEHAT10 = 39;
	
	public static byte ANGEL1 = 40;
	public static byte ANGEL3 = 41;
	public static byte ANGEL10 = 42;
	
	public static byte DEMON1 = 43;
	public static byte DEMON3 = 44;
	public static byte DEMON10 = 45;
	
	public static byte HIPHOP1 = 46;
	public static byte HIPHOP3 = 47;
	public static byte HIPHOP10 = 48;
	
	public static byte GLAMUR1 = 49;
	public static byte GLAMUR3 = 50;
	public static byte GLAMUR10 = 51;
}
