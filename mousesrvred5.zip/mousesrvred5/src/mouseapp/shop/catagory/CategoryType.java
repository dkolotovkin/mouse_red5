package mouseapp.shop.catagory;

public class CategoryType {
	public static int GAME_INVENTORY = 1;
	public static int HEALING_INVENTORY = 2;
	public static int MOUSES = 3;
	public static int ACCESSORIES = 4;
	public static int PRESENTS = 5;
}
