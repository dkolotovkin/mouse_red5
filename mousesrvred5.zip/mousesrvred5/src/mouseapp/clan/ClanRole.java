package mouseapp.clan;

public class ClanRole {
	public static byte NO_ROLE = 0;
	public static byte INVITED = 1;
	public static byte ROLE1 = 2;
	public static byte ROLE2 = 3;
	public static byte ROLE3 = 4;
	public static byte ROLE4 = 5;
	public static byte ROLE5 = 6;
	public static byte OWNER = 7;
}
