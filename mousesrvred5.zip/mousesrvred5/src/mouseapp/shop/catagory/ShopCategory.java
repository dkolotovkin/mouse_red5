package mouseapp.shop.catagory;

public class ShopCategory {
	public int id;
	public String title;
	
	public ShopCategory(int id, String title){
		this.id = id;
		this.title = title;
	}
}
