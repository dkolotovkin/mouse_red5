package mouseapp.utils.changeinfo;

public class ChangeInfoParams {
	public static byte USER_MONEY = 0;
	public static byte USER_EXPERIENCE = 1;
	public static byte USER_POPULAR = 2;
	public static byte USER_EXPERIENCE_AND_POPULAR = 3;
	public static byte USER_MONEY_AND_PET_ENERGY = 4;
	public static byte USER_MONEY_POPULAR = 5;
	public static byte USER_MONEY_EXPERIENCE = 6;
	public static byte USER_MONEY_BANTYPE = 7;
	public static byte USER_MONEY_EXPERIENCE_PET_EXPERIENCE = 8;
	public static byte USER_COLOR_ACCESSORY = 9;
	public static byte USER_EXPERIENCE_MAXEXPERIENCE_LEVEL = 10;
}
