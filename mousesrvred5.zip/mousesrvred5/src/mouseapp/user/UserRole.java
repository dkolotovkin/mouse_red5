package mouseapp.user;

public class UserRole {
	public static byte USER = 0;
	public static byte MODERATOR = 1;
	public static byte ADMINISTRATOR = 2;
	public static byte ADMINISTRATOR_MAIN = 3;
}
