package mouseapp.shop.useresult;


public class UseResult {
	public int error = -1;
	public int itemid = -1;
	public int itemtype = -1;
	public int count = -1;
}
