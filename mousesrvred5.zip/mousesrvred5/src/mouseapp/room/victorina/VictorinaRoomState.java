package mouseapp.room.victorina;

public class VictorinaRoomState {
	public static int QUESTION;
	public static int WAIT;
}
