package mouseapp.shop.buyMoneyResult;

public class BuyMoneyResult {
	public byte error = BuyMoneyErrorCode.ERROR;
	public int money = 0;
}
