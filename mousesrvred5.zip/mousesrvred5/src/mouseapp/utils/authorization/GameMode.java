package mouseapp.utils.authorization;

public class GameMode {
	public static int DEBUG = 0;
	public static int VK = 1;
	public static int MM = 2;
	public static int OD = 3;
	public static int SITE = 4;
}