package mouseapp.utils.sex;

public class Sex {
	public static int MALE = 1;
	public static int FEMALE = 0;
}
